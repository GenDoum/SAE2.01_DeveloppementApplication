﻿namespace Vues
{
    public partial class Accueil : ContentPage
    {
        int count = 0;

        public Accueil()
        {
            InitializeComponent();
        }

    }
}