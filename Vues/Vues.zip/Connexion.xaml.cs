namespace Vues;

public partial class Connexion : ContentPage
{
	public Connexion()
	{
		InitializeComponent();
	}
}