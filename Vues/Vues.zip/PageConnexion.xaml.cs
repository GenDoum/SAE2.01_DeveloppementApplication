namespace Vues;

public partial class PageConnexion : ContentPage
{
	public PageConnexion()
	{
		InitializeComponent();
	}
}