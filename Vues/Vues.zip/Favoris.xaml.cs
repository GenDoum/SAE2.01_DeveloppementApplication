namespace Vues;

public partial class Favoris : ContentPage
{
	public Favoris()
	{
		InitializeComponent();
	}
}